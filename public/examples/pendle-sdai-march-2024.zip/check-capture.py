"""Check the saved sDAI capture and reconcile its real receipts without a network connection."""
import hashlib
import json
from pathlib import Path

directory = Path(__file__).parent
case_bytes = (directory / "case.json").read_bytes()
assert hashlib.sha256(case_bytes).hexdigest() == "a8ffd9788760abd7b1be17155e68cbfd844c292ff52c7e1cbdef31fd957466d5"
assert hashlib.sha256((directory / "entry-calls.json").read_bytes()).hexdigest() == "627bce52e614151b7cb3aebcbc980f49387aa1231f621cce11ddefbf6090b055"
case = json.loads(case_bytes)
reads = case["reads"]
wad = 10**18
yt = reads["settlement"]["contract"]
sy = reads["sy_entry_rate"]["contract"]

def words(raw):
    return [int(raw[i:i + 64], 16) for i in range(2, len(raw), 64)]

def saved(name):
    return words(reads[name]["result"])

def event(transaction, topic):
    return next(log for log in case["receipts"][transaction]["logs"]
                if log["address"] == yt and log["topics"][0] == topic)

# The actual burn and claim came from other participants. Each receipt supplies
# an independent check of the arithmetic used with the simulated positions.
frozen = saved("settlement")[0]
burn_tx = "0x3813f5216294922de90b79982a9e0ca897cc0aea0eb3a20d2dd1692f275ea8ad"
burn = event(burn_tx, "0x5d624aa9c148153ab3446c1b154f660ee7701e549fe9b62dab7171b1c80e6fa2")
pt, redeemed = words(burn["data"])
assert pt * wad // frozen == redeemed

claim_tx = "0x45367012f6706ce0c0c407cc67b89d1154106e5ec699338109c38e3046204224"
claim = event(claim_tx, "0x83a945bd12c713615b59a6e48a3467c05d1a7442350600d6f7fce6af9f7190e9")
prior, accrued = saved("actual_claim_previous_interest")
balance = saved("actual_claim_previous_balance")[0]
gross = accrued + balance * (frozen - prior) * wad // (frozen * prior)
fee = gross * saved("actual_claim_fee")[0] // wad
assert words(claim["data"]) == [gross - fee]
transfers = [log for log in case["receipts"][claim_tx]["logs"] if log["address"] == sy
             and log["topics"][0] == "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"
             and log["topics"][1][-40:] == yt[2:]]
payments = {log["topics"][2]: words(log["data"])[0] for log in transfers}
assert payments.pop(claim["topics"][1]) == gross - fee and list(payments.values()) == [fee]

# Match modeled claims to the historical redemption previews, keeping the
# integer truncation used by the deployed contracts in both conversions.
start = saved("yt_entry_index")[0]
rate = saved("yt_fee_at_claim")[0]
for budget in (100, 1000):
    pt = words(case["entry_simulations_raw"][f"pt_{budget}"])[0]
    held = words(case["entry_simulations_raw"][f"hold_{budget}"])[0]
    suffix = "100_19529386" if budget == 100 else "1000"
    assert int(reads[f"pt_redemption_{suffix}"]["calldata"][-64:], 16) == pt * wad // frozen
    assert int(reads[f"holding_redemption_{suffix}"]["calldata"][-64:], 16) == held
purchased = words(case["entry_simulations_raw"]["yt_100"])[0]
interest = purchased * (frozen - start) * wad // (frozen * start)
assert int(reads["yt_sale_claim_100_19529386"]["calldata"][-64:], 16) == interest - interest * rate // wad
print("Capture and simulation inputs match their published digests. The PT redemption, YT payout, and modeled redemption quantities reconcile.")
