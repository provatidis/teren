# A month of sDAI on Pendle

**Ethereum · February 27 to March 28, 2024**

On February 27, the Dai Savings Rate was 5%. Pendle’s spot PT price implied 5.35% annualized over the days remaining. A buyer had to decide what the deposit would earn over the *next* month. On March 10, Maker raised the savings rate to 15%. The deposit ultimately earned 0.8324% over the 30 days between the entry and expiry blocks, equivalent to 10.61% annualized. [Entry block](https://etherscan.io/block/19315170) · [Governance execution](https://etherscan.io/tx/0xe240a729ad47657367fa85cb28bb1aed25588394f80464c78bdcd1c95c6d89ca) · [Expiry block](https://etherscan.io/block/19528924)

## What 1,000 DAI could buy

I selected the March 2024 Ethereum sDAI market for its single savings rate and DAI accounting. I fixed entry at the first block at or after 30 days before expiry, with 1,000 DAI for each independent strategy, before calculating any strategy outcomes.

The PT quote led to 1,004.21 DAI at settlement. Holding sDAI led to 1,008.35 DAI. The pool could absorb only about **201.05 DAI** in a direct YT purchase at that block. Quoting increasingly large exact YT quantities located the boundary at 45,135.750123 YT to the nearest millionth of a token. The next millionth triggered Pendle’s market-proportion limit. This describes this pool at this block. Other venues, orders and subsequent blocks were outside the comparison. [Pendle market](https://etherscan.io/address/0xd16cb4138a0f09885defdbc1fe4a65a8f2fb3950) · [Pendle’s error guide](https://docs.pendle.finance/pendle-v2-dev/Troubleshooting)

## The same decision with 100 DAI

I selected 100 DAI for a separate, smaller comparison after the 1,000 DAI quote failed and before calculating the strategy outcomes. Each alternative starts with the same budget and sees the same pool state. The results use the first actual post-expiry settlement block.

| Alternative | What the budget bought | Value at settlement |
|---|---|---:|
| Buy PT | 100.412643 PT | 100.41 DAI |
| Buy YT | 22,712.613887 YT | 183.96 DAI |
| Hold sDAI | 94.562699 sDAI | 100.83 DAI |

The YT buyer purchased a month of interest on roughly 22,713 DAI of principal. If the savings rate had stayed at 5% and settlement occurred at scheduled maturity, the same claim would have paid about **88.53 DAI**. This counterfactual keeps the quoted entry size and the historical 3% fee on YT interest. The governance vote occurred after entry. [Maker’s March 8 proposal](https://vote.makerdao.com/executive/template-executive-vote-out-of-schedule-executive-vote-increase-edsr-increase-stability-fees-decrease-gsm-delay-usdc-psm-throughput-change-trigger-spark-proxy-spell-march-8-2024)

## What the figures represent

- **Entry.** Block 19,315,170, February 27 at 00:00:11 UTC. The previous block was before midnight. For each budget, the sDAI contract’s deposit preview and Pendle SY’s preview returned the same number of shares. The marginal PT price was 0.995725079489936509 DAI. The quoted trades account for pool fees and the effect of trade size.
- **Quote method.** For PT the historical Router Static supplied the starting exact-input quote. The reported holdings use the full swap simulation. Its 1,000 DAI fill differed from the static estimate by 0.000000000000000561 PT. Its default YT exact-input search also reverted for the smaller budget. For YT I therefore asked what exact quantities cost. The recorded quotes bracket the largest YT purchase affordable with 100 DAI to one millionth of a YT. I then simulated the full historical Pendle Router V3 call using that quantity as the starting estimate. It spent 100 DAI and returned exactly 22,712.613887 YT. The PT purchases and the direct sDAI deposits also ran through the historical contracts. Each alternative was simulated separately, with only the synthetic buyer’s DAI balance and allowance supplied. No transactions were broadcast. [Router V3](https://etherscan.io/address/0x00000000005bbb0ef59571e58418f9a4357b68a0)
- **Underlying.** Maker’s Pot rate changed from 5% to 15% in block 19,406,924, on March 10 at 19:56:23 UTC. Compounding each rate for the time it applied independently reproduces the vault’s 30-day growth. The 13% rate considered near the end of March took effect on March 29, after maturity. [March 29 execution](https://etherscan.io/tx/0x13cb364c2019ca51372a9e943f0963a0b3c53bfd8360ea0397a572b6cd3671a9)
- **Timing.** Contractual expiry was March 28 at 00:00:00 UTC. The first expiry block was 19,528,924 at 00:00:11. The first transaction to lock the final interest index was in block 19,529,386 at 01:36:47. All headline outcomes use the latter block. A hypothetical immediate settlement in the first expiry block would have paid 183.38 DAI to the 100 DAI YT position. A real user can change this timing by interacting with the contract. [First settlement](https://etherscan.io/tx/0x3813f5216294922de90b79982a9e0ca897cc0aea0eb3a20d2dd1692f275ea8ad)
- **Interest and costs.** The actual factory fee at settlement was 3%. The calculation leaves accrued interest in SY until claim, then uses the historical DAI redemption preview. The endpoints listed no reward tokens for SY or YT. PENDLE emissions belonged to LPs. Spark’s sDAI snapshot dates fell outside this holding period. Its contemporaneous pre-farm rewarded DAI borrowing or ETH supply. No offchain incentives were valued. Gas is excluded. These figures are denominated in DAI. [Spark snapshot dates](https://docs.spark.finance/airdrop/ignition) · [Pre-farm eligibility](https://docs.spark.finance/airdrop/pre-farm)
- **Receipts.** The first settlement transaction burned 71,021.205755593528525102 PT and delivered 66,603.447035071365731047 SY. The historical redemption calculation matches both quantities. In a separate holder’s real YT claim, the prior balance, prior index and accrued SY reproduce 16,022.477799659978816026 SY paid to the holder and 495.540550504947798433 SY paid to the treasury, to the smallest unit. [Actual PT redemption](https://etherscan.io/tx/0x3813f5216294922de90b79982a9e0ca897cc0aea0eb3a20d2dd1692f275ea8ad#eventlog) · [Actual YT claim](https://etherscan.io/tx/0x45367012f6706ce0c0c407cc67b89d1154106e5ec699338109c38e3046204224#eventlog)

## Reproduction

Unzip the bundle and run `python3 check-capture.py` to check the published capture and replay the payout arithmetic offline.

The included Python 3 script requires only the standard library and access to an Ethereum archive node. It reads raw contract data, reconstructs both actual payouts, verifies block hashes, reruns the simulated purchases and vault deposits, and checks adjacent quotes at the two YT size boundaries. The provider must accept historical eth_call state overrides for the simulated buyer. The capture contains the raw contract returns and revert data. The companion entry-calls.json supplies the calldata and temporary DAI overrides to replay the simulations. The evidence reproduced byte for byte on dRPC and Nodies. Run from this directory.

```sh
python3 reproduce.py https://eth.drpc.org > fresh.json
python3 reproduce.py https://ethereum-public.nodies.app --witness case.json > second.json
cmp case.json fresh.json
cmp case.json second.json
```

The optional witness speeds up price discovery by reading the two candidate quantities from the capture. The independent node must still price each candidate and its neighbor and satisfy the same assertions.

[Historical router](https://etherscan.io/address/0x263833d47ea3fa4a30f269323aba6a107f9eb14c) · [Deployed YT source](https://eth.blockscout.com/address/0x013889973cced40030175d138c685266b055e3f4?tab=contract) · [Savings DAI implementation](https://github.com/sky-ecosystem/sdai/blob/master/src/SavingsDai.sol)
