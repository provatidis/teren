"""Reconstruct the March 2024 sDAI case. Python 3.9+ and a historical Ethereum RPC.
Usage: python3 reproduce.py https://eth.drpc.org > result.json
All network operations are read-only. The buys are separate hypothetical alternatives.
"""
import argparse
import json
from pathlib import Path
import time
import urllib.request
from datetime import datetime, timezone
from decimal import Decimal, getcontext

getcontext().prec = 72
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("rpc")
parser.add_argument("--witness", help="Use the previously discovered quantities and independently verify both adjacent boundary quotes.")
args = parser.parse_args()
rpc = args.rpc
witness = json.loads(open(args.witness).read()) if args.witness else None
W = 10**18
ENTRY = 19315170
EXPIRY = 19528924
SETTLE = 19529386
CHANGE = 19406924
MARKET = "0xd16cb4138a0f09885defdbc1fe4a65a8f2fb3950"
SY = "0x90f1935f733dd8826dca2bd01ccfc600f20e978e"
PT = "0xac0650178e8be0c26b25673618c7be465a40aaf9"
YT = "0x013889973cced40030175d138c685266b055e3f4"
DAI = "0x6b175474e89094c44da98b954eedeac495271d0f"
SDAI = "0x83f20f44975d03b1b09e64809b757c47f942beea"
POT = "0x197e90f9fad81970ba7976f33cbd77088e5d7cf7"
ROUTER = "0x263833d47ea3fa4a30f269323aba6a107f9eb14c"
FREEZE_TX = "0x3813f5216294922de90b79982a9e0ca897cc0aea0eb3a20d2dd1692f275ea8ad"
FEE_TX = "0x45367012f6706ce0c0c407cc67b89d1154106e5ec699338109c38e3046204224"
NEW_DSR_TX = "0xe240a729ad47657367fa85cb28bb1aed25588394f80464c78bdcd1c95c6d89ca"
SIG = {
    "readTokens()":"2c8ce6bc", "expiry()":"e184c9be", "getRewardTokens()":"c4f59f9b",
    "exchangeRate()":"3ba0b9a9", "previewDeposit(address,uint256)":"b8f82b26",
    "previewRedeem(address,uint256)":"cbe52ae3", "previewRedeem(uint256)":"4cdad506",
    "previewDeposit(uint256)":"ef8b30f7", "pyIndexCurrent()":"1d52edc4",
    "postExpiry()":"0a2b83a7", "factory()":"c45a0155", "interestFeeRate()":"dd86fea1",
    "getPtToAssetRate(address)":"f2344deb", "swapExactSyForPtStatic(address,uint256)":"b1f36065",
    "swapExactSyForYtStatic(address,uint256)":"8c0cc77c", "swapSyForExactYtStatic(address,uint256)":"25cadd2c",
    "dsr()":"487bf082", "userInterest(address)":"d68076c3", "balanceOf(address)":"70a08231"
}
captured = {}
entry_calls = json.loads(Path(__file__).with_name("entry-calls.json").read_text())
executions = {}
class RPCError(Exception):
    pass

def request(method, params):
    req = urllib.request.Request(rpc, json.dumps(dict(id=1,jsonrpc="2.0",method=method,params=params)).encode(), {"Content-Type":"application/json","User-Agent":"Teren-historical-research/1"})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=30) as response:
                obj = json.load(response)
            if "error" in obj:
                raise RPCError(obj["error"])
            return obj["result"]
        except (OSError, TimeoutError):
            if attempt == 3:
                raise
            time.sleep(1+attempt)

def call(block, address, sig, *args, label=None, expect_limit=False):
    data = "0x"+SIG[sig]+"".join(format(int(x,16) if isinstance(x,str) else x,"064x") for x in args)
    try:
        raw = request("eth_call",[{"to":address,"data":data},hex(block)])
        assert raw.startswith("0x") and len(raw)>2 and (len(raw)-2)%64==0
        words = [int(raw[i:i+64],16) for i in range(2,len(raw),64)]
    except RPCError as exc:
        err=exc.args[0]; raw=err.get("data")
        if isinstance(raw,dict):
            raw=raw.get("data")
        if not expect_limit or not isinstance(raw,str) or not raw.startswith("0xfc68d09e"):
            raise
        words=None
    if label:
        captured[label]={"block":block,"contract":address,"method":sig,"calldata":data,"result" if words is not None else "revert":raw}
    return words

def block_header(n):
    b=request("eth_getBlockByNumber",[hex(n),False])
    return dict(number=n,hash=b["hash"],parentHash=b["parentHash"],timestamp=int(b["timestamp"],16),
                utc=datetime.fromtimestamp(int(b["timestamp"],16),timezone.utc).isoformat())

headers={n:block_header(n) for n in [ENTRY-1,ENTRY,CHANGE-1,CHANGE,EXPIRY-1,EXPIRY,SETTLE-1,SETTLE]}
expiry=call(ENTRY,YT,"expiry()",label="contract_expiry")[0]
assert headers[ENTRY-1]["timestamp"]<expiry-30*86400<=headers[ENTRY]["timestamp"]
assert headers[EXPIRY-1]["timestamp"]<expiry<=headers[EXPIRY]["timestamp"]
for n in [ENTRY,CHANGE,EXPIRY,SETTLE]:
    assert headers[n-1]["hash"]==headers[n]["parentHash"]
assert call(ENTRY,MARKET,"readTokens()",label="market_tokens")==[int(a,16) for a in [SY,PT,YT]]
factory="0x"+format(call(ENTRY,YT,"factory()",label="factory")[0],"040x")
for n in [ENTRY,SETTLE]:
    for token in [SY,YT]:
        assert call(n,token,"getRewardTokens()",label=f"reward_tokens_{token}_{n}")==[32,0]
old_rate,new_rate=[call(n,POT,"dsr()",label=f"maker_rate_{n}")[0] for n in [ENTRY,SETTLE]]
assert call(CHANGE-1,POT,"dsr()",label="dsr_before_change")[0]==old_rate
assert call(CHANGE,POT,"dsr()",label="dsr_after_change")[0]==new_rate
entry_index=call(ENTRY,YT,"pyIndexCurrent()",label="yt_entry_index")[0]
entry_sy_rate=call(ENTRY,SY,"exchangeRate()",label="sy_entry_rate")[0]
assert entry_index==entry_sy_rate
assert call(SETTLE-1,YT,"postExpiry()",label="before_settlement")[0]==0
frozen=call(SETTLE,YT,"postExpiry()",label="settlement")[0]
assert frozen>entry_index
for n in [EXPIRY,SETTLE]:
    assert call(n,YT,"pyIndexCurrent()",label=f"current_py_index_{n}")[0]==call(n,SY,"exchangeRate()",label=f"sy_rate_{n}")[0]
assert frozen==call(SETTLE,YT,"pyIndexCurrent()")[0]
fee=call(SETTLE,factory,"interestFeeRate()",label="yt_fee_at_claim")[0]
spot=call(ENTRY,ROUTER,"getPtToAssetRate(address)",MARKET,label="marginal_pt_reference")[0]

def quote_out(yt, label=None):
    return call(ENTRY,ROUTER,"swapSyForExactYtStatic(address,uint256)",MARKET,yt,label=label,expect_limit=True)

def simulate(leg, budget):
    key=f"{leg}_{budget}"
    message, block, overrides=entry_calls[key]
    assert int(block,16)==ENTRY and [x.lower() for x in overrides]==[DAI]
    router="0x00000000005bbb0ef59571e58418f9a4357b68a0"
    assert message["to"].lower()==(SDAI if leg=="hold" else router)
    assert message["from"]=="0x"+"11"*20
    changes=list(overrides.values())[0]["stateDiff"]
    assert len(changes)==2 and all(int(x,16)==budget*W for x in changes.values())
    # Only balance and allowance are supplied to this synthetic account. Verify
    # both through actual DAI getters on the same read-only override state.
    sender=message["from"][2:].zfill(64)
    spender=message["to"][2:].lower().zfill(64)
    for data in ["0x70a08231"+sender,"0xdd62ed3e"+sender+spender]:
        assert int(request("eth_call",[{"to":DAI,"data":data},block,overrides]),16)==budget*W
    raw=request("eth_call",[message,block,overrides])
    executions[key]=raw
    return [int(raw[i:i+64],16) for i in range(2,len(raw),64)]

# Whole test increments are 0.000001 YT; final adjacent boundary quotes are saved.
step=10**12
def affordable(max_sy=None):
    def fits(k):
        q=quote_out(k*step)
        return q is not None and (max_sy is None or q[0]<=max_sy)
    lo,hi=0,100000*W//step
    while fits(hi):
        lo,hi=hi,2*hi
    while hi-lo>1:
        mid=(lo+hi)//2
        if fits(mid):
            lo=mid
        else:
            hi=mid
    return lo*step

def shares(budget):
    s=call(ENTRY,SY,"previewDeposit(address,uint256)",DAI,budget*W,label=f"mint_SY_{budget}")[0]
    assert s==call(ENTRY,SDAI,"previewDeposit(uint256)",budget*W,label=f"mint_sdai_{budget}")[0]
    return s

def assets(n,sy,label):
    dai=call(n,SY,"previewRedeem(address,uint256)",DAI,sy,label=label)[0]
    assert dai==call(n,SDAI,"previewRedeem(uint256)",sy)[0]
    return dai

def rate(term_growth, seconds):
    return str(((1+Decimal(term_growth))**(Decimal(365*86400)/seconds)-1)*100)

def value(raw):
    return str(Decimal(raw)/W)

def settlement_values(n, budget, sy_budget, pt, yt, reserve_sy, closing, rate_fee):
    # On settlement the PY freeze and PT conversion index coincide; also calculate
    # a separate prompt-redemption counterfactual at the very first expiry block.
    pt_sy=pt*W//closing
    pt_dai=assets(n,pt_sy,f"pt_redemption_{budget}_{n}")
    hold_dai=assets(n,sy_budget,f"holding_redemption_{budget}_{n}")
    gross=yt*(closing-entry_index)*W//(closing*entry_index)
    net=gross-gross*rate_fee//W
    yt_dai=assets(n,net+reserve_sy,f"yt_sale_claim_{budget}_{n}")
    return dict(PT=value(pt_dai),YT=value(yt_dai),hold=value(hold_dai),
                gross_yt_interest_sy_raw=str(gross),net_yt_interest_sy_raw=str(net))

cap=int(Decimal(witness["maximum_direct_YT_units"])*W) if witness else affordable()
cap_quote=quote_out(cap,"last_feasible_at_micro_yt_precision")
assert quote_out(cap+step,"next_micro_yt_reverts") is None
cap_cost_sy=cap_quote[0]
cap_dai=assets(ENTRY,cap_cost_sy,"maximum_single_pool_YT_cost_in_DAI")
budgets={}
for budget in [1000,100]:
    s=shares(budget)
    assert simulate("hold",budget)==[s]
    pt_quote=call(ENTRY,ROUTER,"swapExactSyForPtStatic(address,uint256)",MARKET,s,label=f"pt_exact_input_{budget}")
    qty_pt, pt_fee, wrapped_pt=simulate("pt",budget)
    assert wrapped_pt==s and pt_fee==pt_quote[1]
    # Use the full router output. On the larger order it differs from the
    # static estimate by 561 units of 1e-18 PT due to integer rounding.
    assert abs(qty_pt-pt_quote[0])<10**6
    exact_input_yt=call(ENTRY,ROUTER,"swapExactSyForYtStatic(address,uint256)",MARKET,s,label=f"yt_default_approximation_{budget}",expect_limit=True)
    if cap_cost_sy<s:
        assert exact_input_yt is None
        budgets[budget]={"full_YT_purchase":"pool proportion guard prevents spending the full budget",
                         "PT":value(assets(SETTLE,qty_pt*W//frozen,"pt_redemption_1000")),
                         "hold":value(assets(SETTLE,s,"holding_redemption_1000"))}
        continue
    qty_yt=int(Decimal(witness["budgets"][str(budget)]["qty_YT"])*W) if witness else affordable(s)
    q=quote_out(qty_yt,f"affordable_yt_{budget}")
    assert quote_out(qty_yt+step,f"next_yt_above_budget_{budget}")[0]>s
    dust=s-q[0]
    assert 0<=dust<10**10
    simulated_yt, yt_fee, wrapped_yt=simulate("yt",budget)
    assert (simulated_yt,yt_fee,wrapped_yt)==(qty_yt,q[1],s)
    outcomes={}
    for n in [EXPIRY,SETTLE]:
        idx=call(n,YT,"pyIndexCurrent()")[0]
        f=call(n,factory,"interestFeeRate()",label=f"claim_fee_{n}")[0]
        outcomes[n]=settlement_values(n,budget,s,qty_pt,qty_yt,0,idx,f)
    budgets[budget]=dict(qty_PT=value(qty_pt),qty_YT=value(qty_yt),exact_output_quote_headroom_SY=value(dust),
                         buy_YT_fee_in_SY=value(q[1]),outcomes=outcomes)

# Retain on-chain event receipts as a separate category of evidence; never
# infer that an observed account placed one of the hypothetical entry trades.
receipts={}
for h in [FREEZE_TX,FEE_TX,NEW_DSR_TX]:
    rec=request("eth_getTransactionReceipt",[h])
    assert int(rec["status"],16)==1
    receipts[h]={"block":int(rec["blockNumber"],16),"hash":rec["blockHash"],
                 "logs":[{k:v for k,v in log.items() if k in ["address","topics","data","logIndex"]}
                         for log in rec["logs"] if log["address"].lower() in [YT,SY,POT]]}
assert receipts[FREEZE_TX]["hash"]==headers[SETTLE]["hash"]
def indexed_event(logs, emitter, topic):
    return next(log for log in logs if log["address"].lower()==emitter and log["topics"][0]==topic)

freeze_logs=receipts[FREEZE_TX]["logs"]
new_index=indexed_event(freeze_logs,YT,"0x71475f2f645813fdbebf53a58968008bff11ee21a58f01c5a9cc263d0bc4703d")
assert int(new_index["topics"][1],16)==frozen
burn=indexed_event(freeze_logs,YT,"0x5d624aa9c148153ab3446c1b154f660ee7701e549fe9b62dab7171b1c80e6fa2")
burned,paid_sy=int(burn["data"][2:66],16),int(burn["data"][66:],16)
assert burned*W//frozen==paid_sy
claim=receipts[FEE_TX]
claim_block=claim["block"]
redeem=indexed_event(claim["logs"],YT,"0x83a945bd12c713615b59a6e48a3467c05d1a7442350600d6f7fce6af9f7190e9")
holder="0x"+redeem["topics"][1][-40:]
balance=call(claim_block-1,YT,"balanceOf(address)",holder,label="actual_claim_previous_balance")[0]
previous,accrued=call(claim_block-1,YT,"userInterest(address)",holder,label="actual_claim_previous_interest")
claim_fee=call(claim_block,factory,"interestFeeRate()",label="actual_claim_fee")[0]
gross_claim=accrued+balance*(frozen-previous)*W//(frozen*previous)
fee_claim=gross_claim*claim_fee//W
net_claim=gross_claim-fee_claim
assert int(redeem["data"],16)==net_claim
transfers=[log for log in claim["logs"] if log["address"].lower()==SY and log["topics"][0]=="0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef" and log["topics"][1][-40:]==YT[2:]]
assert len(transfers)==2
assert sum(int(log["data"],16) for log in transfers)==gross_claim
assert any(log["topics"][2][-40:]==holder[2:] and int(log["data"],16)==net_claim for log in transfers)
assert receipts[NEW_DSR_TX]["hash"]==headers[CHANGE]["hash"]
receipt_checks={"real_PT_burned":value(burned),"real_SY_for_PT":value(paid_sy),
               "real_YT_claim_holder":holder,"real_claim_SY_to_holder":value(net_claim),"real_claim_SY_to_treasury":value(fee_claim)}
for n in [ENTRY,CHANGE,EXPIRY,SETTLE]:
    assert block_header(n)["hash"]==headers[n]["hash"]
term=expiry-headers[ENTRY]["timestamp"]
out=dict(chain=1,selection="Ethereum sDAI maturing 2024-03-28. First block at or after 30 days before expiry; 1,000 DAI per alternative. Supplemental 100 DAI was selected after the full-size quote reverted and before examining strategy outcomes.",
         valuation="First actual settlement for all alternatives. A separate 100 DAI prompt-midnight valuation simulates a first settlement at the first expiry block. DAI units; no gas, other venues, or unpriced incentives.",
         block_headers=headers,spot_pt_in_DAI=value(spot),spot_entry_implied_APY_pct=rate(Decimal(W)/spot-1,term),
         maximum_direct_YT_units=value(cap),maximum_direct_YT_cost_DAI=value(cap_dai),
         historical_YT_interest_fee_pct=value(fee*100),budgets=budgets,receipt_checks=receipt_checks,entry_simulations_raw=executions,reads=captured,receipts=receipts)
print(json.dumps(out,indent=2,sort_keys=True))
